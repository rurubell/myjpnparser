package src.data;


import java.util.ArrayList;


//Для хранения слова из JMDICT
public class MyJMDictPos
{
	private String s_kanji = "";
	private String s_kana = "";
	private ArrayList< String > s_translations = new ArrayList< String >(); //Список переводов
	
	//Сеттеры
	public void setKanji( String s_kanji ) { this.s_kanji = s_kanji; }
	public void setKana( String s_kana ) { this.s_kana = s_kana; }
	public void setTranslations( ArrayList< String > s_translations ) { this.s_translations = s_translations; }
	public void addTranslation( String s_translation ) { this.s_translations.add( s_translation ); }
	
	//Геттеры
	public String getKanji() { return this.s_kanji; }
	public String getKana() { return this.s_kana; }
	public ArrayList< String > getTranslations() { return this.s_translations; }
	
	
	public MyJMDictPos() {}
	public MyJMDictPos( String s_kanji, String s_kana, ArrayList< String > s_translations )
	{
		this.setKanji( s_kanji );
		this.setKana( s_kana );
		this.setTranslations( s_translations );
	}
	
	
	//Show
	public void show()
	{
		System.out.println( "Kanji: " + this.getKanji() );
		System.out.println( "Kana: " + this.getKana() );
		System.out.println( "Translations:" );
		
		for( String s_pos : this.getTranslations() )
		{
			System.out.println( "\t" + s_pos );
		}
		
		System.out.println();
	}
}
