package src.data;


public class MyJMDICAnswer
{
	private String s_word = "";
	private String s_reading = "";
	private String s_translation = "";
	private String s_ru_translation = "";
	private int n_jlpt_lev = -1;
	private boolean b_common = false;
	
	//Геттеры
	public String getWord() { return this.s_word; }
	public String getReading() { return this.s_reading; }
	public String getTranslation() { return this.s_translation; }
	public String getRuTranslation() { return this.s_ru_translation; }
	public int getJLPTLev() { return this.n_jlpt_lev; }
	public boolean isCommon() { return this.b_common; }
	
	//Сеттеры
	public void setJLPTLev( int n_jlpt_lev ) { this.n_jlpt_lev = n_jlpt_lev; }
	
	
	public MyJMDICAnswer
	(
		String s_word,
		String s_reading,
		String s_translation,
		String s_ru_translation
	)
	{
		this.s_word = s_word;
		this.s_reading = s_reading;
		this.s_translation = s_translation;
		this.s_ru_translation = s_ru_translation;
	}
}
