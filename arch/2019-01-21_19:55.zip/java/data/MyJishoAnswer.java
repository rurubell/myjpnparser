package src.data;


public class MyJishoAnswer
{
	private String s_word = "";
	private String s_reading = "";
	private String s_translation = "";
	private int n_jlpt_lev = -1;
	private boolean b_common = false;
	
	//Геттеры
	public String getWord() { return this.s_word; }
	public String getReading() { return this.s_reading; }
	public String getTranslation() { return this.s_translation; }
	public int getJLPTLev() { return this.n_jlpt_lev; }
	public boolean isCommon() { return this.b_common; }
	
	//Сеттеры
	public void setJLPTLev( int n_jlpt_lev ) { this.n_jlpt_lev = n_jlpt_lev; }
	
	
	public MyJishoAnswer
	(
		String s_word,
		String s_reading,
		String s_translation
	)
	{
		this.s_word = s_word;
		this.s_reading = s_reading;
		this.s_translation = s_translation;
	}
	
	
	//Конструктор - парсер ответа сервиса Jisho.org
	public MyJishoAnswer( String s_word, String s_jisho_answer )
	{
		this.s_word = s_word;
		this.s_translation = this.getEnglishTranslations( s_jisho_answer );
		this.s_reading = this.getReading( s_jisho_answer );
		this.b_common = this.isCommon( s_jisho_answer );
	}
	
	
	//Получить английские переводы для слова
	private String getEnglishTranslations( String s_resp )
	{
		String s_res = "";
		
		try
		{
			String s_start_tag = "\"english_definitions\":[";
			String s_end_tag = "]";
			
			int n_start = s_resp.indexOf( s_start_tag ) + s_start_tag.length();
			int n_end = s_resp.indexOf( s_end_tag, n_start );
			
			s_res += s_resp.substring( n_start, n_end );
			s_res = s_res.replace( "\"", "" );
			s_res = s_res.replace( ",", ", " );
		}
		catch( Exception e ) { e.printStackTrace(); }
		
		return s_res;
	}
	
	
	//Получить чтение для слова
	private String getReading( String s_resp )
	{
		String s_res = "";
		
		try
		{
			String s_start_tag = "\"reading\":";
			String s_end_tag = "}";
			
			int n_start = s_resp.indexOf( s_start_tag ) + s_start_tag.length();
			int n_end = s_resp.indexOf( s_end_tag, n_start );
			
			s_res += s_resp.substring( n_start, n_end );
			s_res = s_res.replace( "\"", "" );
		}
		catch( Exception e ) { e.printStackTrace(); }
		
		return s_res;
	}
	
	
	//Это common word?
	private boolean isCommon( String s_resp )
	{
		if( s_resp.indexOf( "\"is_common\":true" ) != -1 ) { return true; }
		return false;
	}
}
