package src.ui.panel;


import javax.swing.*;


public class MyPanel extends Thread
{
	public JPanel getPanel() { return new JPanel(); }
}
