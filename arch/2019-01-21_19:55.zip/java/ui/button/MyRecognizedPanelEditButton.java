package src.ui.button;


import javax.swing.*;
import java.awt.*;


public class MyRecognizedPanelEditButton extends JButton
{
	public MyRecognizedPanelEditButton( String s_label )
	{
		super( s_label );
		this.setFont( new Font( "Liberation Sans", Font.PLAIN, 13 ) );
	}
}
