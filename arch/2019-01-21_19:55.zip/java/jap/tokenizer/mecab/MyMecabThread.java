package src.jap.tokenizer.mecab;


import java.lang.ProcessBuilder;


public class MyMecabThread
{
	
}
