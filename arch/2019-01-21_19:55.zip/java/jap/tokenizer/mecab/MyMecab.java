package src.jap.tokenizer.mecab;


import java.lang.ProcessBuilder;

import java.util.ArrayList;

import src.jap.tokenizer.MyTokenizer;
import src.data.MyJapanWord;
import src.util.log.MyLogToStdout;


public class MyMecab implements MyTokenizer
{
	public ArrayList< MyJapanWord > getWordsArrayList( String s_text )
	{
		return null;
	}
}
