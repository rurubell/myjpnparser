package src.jap.jisho;


import src.net.MyGetSender;
import src.data.MyJishoAnswer;
import java.net.URLEncoder;


public class MyJishoThread extends Thread
{
	private String s_jisho_api_link = "https://jisho.org/api/v1/search/words?keyword=";
	
	
	private String s_word = null;
	private MyJishoAnswer mja = null;
	
	
	MyJishoThread( String s_word ) { this.s_word = s_word; }
	
	
	//Получить ответ
	public MyJishoAnswer getJishoAnswer() { return this.mja; }
	
	
	@Override
	public void run()
	{
		MyGetSender mgs = new MyGetSender();
		String s_resp = "";
		String s_parameter = "";
		
		try{ s_parameter = URLEncoder.encode( this.s_word, "UTF-8" ); }
		catch( Exception e ) { e.printStackTrace(); }
		
		s_resp = mgs.sendGET( this.s_jisho_api_link + s_parameter );
		
		this.mja = new MyJishoAnswer( this.s_word, s_resp );
	}
}
