package src.jap.jisho;


import java.util.ArrayList;

import src.jap.jisho.*;
import src.data.MyJishoAnswer;
import src.data.MyJapanWord;


public class MyJisho
{
	//перевод нескольких слов
	public ArrayList< MyJishoAnswer > translate( ArrayList< String > s_words )
	{
		ArrayList< MyJishoAnswer > mja_res_list = new ArrayList< MyJishoAnswer >();
		ArrayList< MyJishoThread > mjt_list = new ArrayList< MyJishoThread >();
		
		try
		{
			for( String s_word : s_words ) 
			{
				MyJishoThread mjt_pos = new MyJishoThread( s_word ); 
				mjt_list.add( mjt_pos );
			}
			for( MyJishoThread mjt_pos : mjt_list ) { mjt_pos.start(); }
			for( MyJishoThread mjt_pos : mjt_list ) { mjt_pos.join(); }
		}
		catch( Exception e ) { e.printStackTrace(); }
		
		for( MyJishoThread mjt_pos : mjt_list ) 
		{ 
			mja_res_list.add( mjt_pos.getJishoAnswer() );
		}
		
		return mja_res_list;
	}
	
	
	//Перевод одного слова
	public MyJishoAnswer translate( String s_word )
	{
		MyJishoAnswer mja_res = null;
		
		try
		{
			MyJishoThread mjt = new MyJishoThread( s_word );
			mjt.start();
			mjt.join();
			mja_res = mjt.getJishoAnswer();
		}
		catch( Exception e ) { e.printStackTrace(); }
		
		return mja_res;
	}
}
