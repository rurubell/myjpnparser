package src.jap.myjmdic;


import java.util.ArrayList;

import src.data.MyJMDICAnswer;
import java.util.Map;
import java.util.HashMap;
import java.util.Map.Entry;

import src.file.MyTextFileReader;
import src.params.MyParams;
import src.util.log.MyLogToStdout;


//Класс для работы с файлом-словарем MYJMDIC.XML
public class MyJMDIC
{
	private static Map< String, MyJMDICAnswer > res_map = null;
	private static boolean b_flag = true;
	
	
	public MyJMDIC()
	{
		if( this.b_flag )
		{
			this.b_flag = false;
			this.res_map = this.readToMYJMDICMap();
		}
	}
	
	
	//Перевод одного слова
	public MyJMDICAnswer translate( String s_word )
	{
		MyJMDICAnswer mja_res = this.res_map.get( s_word );
		if( mja_res == null ) { mja_res = new MyJMDICAnswer( "", "", "", "" ); }
		
		return mja_res;
	}
	
	
	//Читаем словарь MYJMDIC в карту
	private Map< String, MyJMDICAnswer > readToMYJMDICMap()
	{
		Map< String, MyJMDICAnswer> res_map = new HashMap< String, MyJMDICAnswer>();
		MyTextFileReader mtfr = new MyTextFileReader();
		MyLogToStdout mlts = new MyLogToStdout();
		mlts.writeMess( "Read MYJMDIC dictionary file: \"" + MyParams.getStringValue( "myjmdic_path" ) + "\"..." );
		
		for( String s_pos : mtfr.readFileAsStringAL( MyParams.getStringValue( "myjmdic_path" ) ) )
		{
			if( this.isCorrectString( s_pos ) ) 
			{
				if( res_map.get( this.parseKanji( s_pos ) ) != null ) {}
				else 
				{ 
					res_map.put( this.parseKanji( s_pos ), this.makeMJMDICAFromString( s_pos ) );
					res_map.put( this.parseKana( s_pos ), this.makeMJMDICAFromString( s_pos ) ); 
				} 
			}
		}
		
		return res_map;
	}
	
	
	//Создать MyJMDICAnswer из строки
	private MyJMDICAnswer makeMJMDICAFromString( String s_xml_str )
	{
		String s_kanji = this.parseKanji( s_xml_str );
		String s_kana = this.parseKana( s_xml_str );
		String s_en_translation = this.parseEnTransl( s_xml_str );
		String s_ru_translation = this.parseRuTransl( s_xml_str );
		
		return new MyJMDICAnswer( s_kanji, s_kana, s_en_translation, s_ru_translation );
	}
	
	
	//Получить кандзи из строки
	private String parseKanji( String s_xml_string )
	{
		String s_res = "";
		String s_start_tag = "<knj>";
		String s_end_tag = "</knj>";
		
		int n_start = s_xml_string.indexOf( s_start_tag ) + s_start_tag.length();
		int n_end = s_xml_string.indexOf( s_end_tag );
		s_res = s_xml_string.substring( n_start, n_end );
		
		return s_res;
	}
	
	
	//Получить кану из строки
	private String parseKana( String s_xml_string )
	{
		String s_res = "";
		String s_start_tag = "<kan>";
		String s_end_tag = "</kan>";
		
		int n_start = s_xml_string.indexOf( s_start_tag ) + s_start_tag.length();
		int n_end = s_xml_string.indexOf( s_end_tag );
		s_res = s_xml_string.substring( n_start, n_end );
		
		return s_res;
	}
	
	
	//Получить английский перевод из строки
	private String parseEnTransl( String s_xml_string )
	{
		String s_res = "";
		String s_start_tag = "<en>";
		String s_end_tag = "</en>";
		
		int n_start = s_xml_string.indexOf( s_start_tag ) + s_start_tag.length();
		int n_end = s_xml_string.indexOf( s_end_tag );
		s_res = s_xml_string.substring( n_start, n_end );
		
		return s_res;
	}
	
	
	//Получить русский_перевод из строки
	private String parseRuTransl( String s_xml_string )
	{
		String s_res = "";
		String s_start_tag = "<ru>";
		String s_end_tag = "</ru>";
		
		int n_start = s_xml_string.indexOf( s_start_tag ) + s_start_tag.length();
		int n_end = s_xml_string.indexOf( s_end_tag );
		s_res = s_xml_string.substring( n_start, n_end );
		
		return s_res;
	}
	
	
	//Получить тип слова из строки
	private String parseType( String s_xml_string )
	{
		String s_res = "";
		String s_start_tag = "<tp>";
		String s_end_tag = "</tp>";
		
		int n_start = s_xml_string.indexOf( s_start_tag ) + s_start_tag.length();
		int n_end = s_xml_string.indexOf( s_end_tag );
		s_res = s_xml_string.substring( n_start, n_end );
		
		return s_res;
	}
	
	
	//Проверка строки на корректность
	public boolean isCorrectString( String s_string )
	{
		if
		(
			( s_string.indexOf( "<knj>" ) != -1 ) && 
			( s_string.indexOf( "</knj>" ) != -1 )
		)
		{ return true; }
		return false;
	} 
}
