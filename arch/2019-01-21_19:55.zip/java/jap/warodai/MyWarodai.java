package src.jap.warodai;


import java.util.ArrayList;
import java.net.URLEncoder;

import src.net.MyGetSender;


//Класс для работы с интернет словарем http://e-lib.ua
public class MyWarodai
{
	private String s_elib_url_1 = "http://www.jardic.ru/search/search_r.php?q=";
	private String s_elib_url_2 = "pg=0&sw=1280";
	
	private String s_word = "";
	
	
	public MyWarodai( String s_word )
	{
		try { this.s_word = URLEncoder.encode( s_word, "UTF-8" ); }
		catch( Exception e ) { e.printStackTrace(); }
	}
	
	
	public String getTranslation()
	{
		String s_res = "";
		
		MyGetSender mgs = new MyGetSender();
		String s_resp = mgs.sendGET( this.s_elib_url_1 + this.s_word + this.s_elib_url_2 );
		
		//s_res = this.deleteTrashDivs( s_resp );
		s_res = s_resp;
		
		return s_res;
	}
	
	
	//Удалить лишние блоки из html блока
	private String deleteTrashDivs( String s_html_response )
	{
		String s_res = "";
		
		try
		{
			int n_start_index = s_html_response.indexOf( "Найдено статей:" );
			s_html_response = s_html_response.substring( n_start_index );
		} catch ( Exception e ) {}
		
		try
		{
			int n_start_index = s_html_response.indexOf( "<table width=\"100%\" style=\"padding-top: 4pt;\">" );
			int n_end_index = s_html_response.indexOf( "</table>", n_start_index ) + new String( "</table>" ).length();
			String s_useless_div = s_html_response.substring( n_start_index, n_end_index );
			s_html_response = s_html_response.replace( s_useless_div, "" );
		} catch ( Exception e ) {}
		
		s_res = s_html_response;
		
		return s_res;
	}
}
