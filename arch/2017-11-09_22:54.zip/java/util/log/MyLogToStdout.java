package src.util.log;


import src.util.time.MyTimeUtils;


public class MyLogToStdout
{
	//Записать сообщение
	public void writeMess( String s_mess )
	{
		MyTimeUtils mtu = new MyTimeUtils();
		s_mess = mtu.getCurrentHumanizedTime() + " - " + s_mess;
		System.out.println( s_mess );
	}
	
	
	//Вставить отступ
	public void jump() { System.out.print( "\n\n" ); }
}
