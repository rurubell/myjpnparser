package src.params;


import java.util.HashMap;
import java.util.Map;


//Класс для хранения параметров конфигурационного файла
public class MyParams
{
	//Хеш-мап в котором хранятся параметры конфига
	private static HashMap< String, String > hm_config = new HashMap< String, String >();
	
	
	//Получить строковое значение из хеш-мапа параметров
	public static String getStringValue( String s_key )
	{
		isKeyOK( s_key );
		return hm_config.get( s_key );
	}
	
	
	//Получить целое значение из хеш-мапа параметров
	public static int getIntValue( String s_key )
	{
		isKeyOK( s_key );
		int n_res = 0;
		try
		{
			n_res = Integer.parseInt( hm_config.get( s_key ) );
		}
		catch( Exception e ) 
		{
			System.out.println( "Недопустимое int значение \"" + hm_config.get( s_key ) + "\" для ключа \"" + s_key + "\"" );
			System.out.println( "Внимание! Значение возврата остается равным 0 (нулю)!" );
		}
		
		return n_res;
	}
	
	
	//Получить значение истина, ложь из хеш-мапа параметров
	public static boolean getBoolValue( String s_key )
	{
		boolean b_res = false;
		
		try
		{
			b_res = Boolean.parseBoolean( hm_config.get( s_key ) );
		}
		catch( Exception e ) 
		{
			System.out.println( "Недопустимое boolean значение \"" + hm_config.get( s_key ) + "\" для ключа \"" + s_key + "\"" );
			System.out.println( "Внимание! Значение поля остается равным false (ложь)!" );
		}
		
		return b_res;
	}
	
	
	//Занести новое значение в хеш-мап
	public static void setValue( String s_key, String s_value )
	{
		hm_config.put( s_key, s_value );
	}
	
	
	//Проверка ключа на существование
	private static void isKeyOK( String s_key )
	{
		if( !hm_config.containsKey( s_key ) )
		{
			System.out.println( "Несуществующий параметр конфигурации \"" + s_key + "\", завершаем работу..." );
			System.exit( 0 );
		}
	}
	
	
	//Печать всех значений конфига
	public static void print()
	{
		System.out.println( "Текущие значения конфигурации:" );
		System.out.println( "Ключ\t\tЗначение" );
		
		for( Map.Entry entry : hm_config.entrySet() ) 
		{
			System.out.println( entry.getKey() + "\t\t" + entry.getValue() );
		}
	}
}
