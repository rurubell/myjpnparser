package src;


import java.util.ArrayList;

import org.atilika.kuromoji.Token;
import org.atilika.kuromoji.Tokenizer;

import src.jap.MyJapTextAnalyzer;
import src.data.MyJapanWord;
import src.ui.MyMainWin;
import src.util.MyExec;
import src.params.MyParams;
import src.net.MyServer;
import src.util.log.MyLogToStdout;
import src.file.MyTextFileReader;
import src.jap.sdcv.MySDCV;
import src.data.MyJMDictPos;
import src.data.MySimKanjiEntry;
import src.jap.jisho.MyJisho;
import src.jap.simkanji.MySimKanji;
import src.jap.warodai.MyWarodai;
import src.jap.elib.MyELIB;
import src.jap.jardic.MyJardic;
import src.ui.win.MyJapToRuJardicTranslateWin;


public class MyMain
{
	public static void main( String[] args )
	{
		MyMain.init( args );
		
		MySimKanji msk = new MySimKanji();
		//MyJLPTLevDeterminer mjlptld = new MyJLPTLevDeterminer();
		MyJapTextAnalyzer mjta = new MyJapTextAnalyzer();
		
		MyLogToStdout mlts = new MyLogToStdout();
		mlts.jump();
		System.gc();
		
		MyServer ms = new MyServer();
		ms.startServer();
	}
	
	
	private static void init( String[] args )
	{
		MyLogToStdout mlts = new MyLogToStdout();
		mlts.writeMess( "Main init..." );
		
		//MyParams.setValue( "jmdict_path", "./JMDICT.XML" ); 
		MyParams.setValue( "jlpt4_path", "./xml/JLPT4.xml" );
		MyParams.setValue( "simkanji_path", "./xml/simkanji.xml" );
		MyParams.setValue( "trans_path", "./bin/bash/translate" );
		//MyParams.setValue( "ansi2html_path", "./bin/bash/ansi2html" ); 
	}
}
