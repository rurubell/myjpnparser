package src.ui.panel;


import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Clipboard;
import javax.swing.border.*;
import java.awt.event.*;

import src.ui.menu.*;
import src.data.MyJapanWord;
import src.jap.MyJapTextAnalyzer;
import src.data.MyJMDictPos;
import src.jap.sdcv.MySDCV;


public class MyAnalyzedSentensePanel extends JPanel
{
	//Цвета слова
	private Color c_alverb_col = Color.decode( "#6600E3" );
	private Color c_adverb_col = Color.decode( "#983FFF" );
	private Color c_adj_col = Color.decode( "#007F15" );
	private Color c_adnom_col = Color.decode( "#BFD000" );
	private Color c_connect_col = Color.decode( "#2C0093" );
	private Color c_noun_col = Color.decode( "#930002" );
	private Color c_particle_col = Color.decode( "#D09200" );
	private Color c_symbol_col = Color.decode( "#000000" );
	private Color c_unknown_col = Color.decode( "#000000" );
	private Color c_verb_col = Color.decode( "#2C0093" );
	
	
	public MyAnalyzedSentensePanel( ArrayList< MyJapanWord > mjw_list )
	{
		this.setLayout( new BoxLayout( this, BoxLayout.PAGE_AXIS ) );
		Border b_titled = BorderFactory.createTitledBorder( "Analyzed sentense" ); 
		this.setBorder( b_titled );
		
		JPanel tagged_panel = this.getTaggedSentensePanelWithFurigana( mjw_list );
		
		this.add( tagged_panel );
	}
	
	
	//Создать панель кнопок с тегированным текстом и фуриганой
	private JPanel getTaggedSentensePanelWithFurigana( ArrayList< MyJapanWord > mjw_list )
	{
		JPanel res_panel = new JPanel();
		res_panel.setBackground( Color.WHITE );
		res_panel.setBorder( BorderFactory.createLineBorder( Color.decode( "#444444" ) ) );
		
		for( MyJapanWord mjw_pos : mjw_list )
		{
			JPanel jp_pos = new JPanel();
			jp_pos.setLayout( new BoxLayout( jp_pos, BoxLayout.PAGE_AXIS ) );
			jp_pos.setBackground( Color.WHITE );
			
			JLabel furigana_label = new JLabel( mjw_pos.getHiragana() );
			if( furigana_label.getText().length() <= 0 ) { furigana_label.setText( " " ); }
			furigana_label.setFont( new Font( "Sans", Font.PLAIN, 15 ) );
			furigana_label.setAlignmentX( Component.CENTER_ALIGNMENT );
			
			JLabel wtype_label = new JLabel( mjw_pos.getType() );
			wtype_label.setFont( new Font( "Sans", Font.PLAIN, 9 ) );
			wtype_label.setAlignmentX( Component.CENTER_ALIGNMENT );
			
			JLabel word_label = new JLabel( mjw_pos.getWord() );
			word_label.setForeground( this.c_unknown_col );
			word_label.setFont( new Font( "Sans", Font.BOLD, 26 ) );
			word_label.setAlignmentX( Component.CENTER_ALIGNMENT );
			
			if( mjw_pos.getType().indexOf( "adnominal" ) != -1 ) { word_label.setForeground( this.c_adnom_col ); }
			if( mjw_pos.getType().indexOf( "noun" ) != -1 ) { word_label.setForeground( this.c_noun_col ); }
			if( mjw_pos.getType().indexOf( "verb" ) != -1 ) { word_label.setForeground( this.c_verb_col ); }
			if( mjw_pos.getType().indexOf( "alverb" ) != -1 ) { word_label.setForeground( this.c_alverb_col ); }
			if( mjw_pos.getType().indexOf( "adverb" ) != -1 ) { word_label.setForeground( this.c_adverb_col ); }
			if( mjw_pos.getType().indexOf( "adjective" ) != -1 ) { word_label.setForeground( this.c_adj_col ); }
			if( mjw_pos.getType().indexOf( "particle" ) != -1 ) { word_label.setForeground( this.c_particle_col ); }
			if( mjw_pos.getType().indexOf( "symbol" ) != -1 ) { word_label.setForeground( this.c_symbol_col ); }
			
			jp_pos.add( furigana_label );
			jp_pos.add( word_label );
			jp_pos.add( wtype_label );
			
			res_panel.add( jp_pos );
		}
		
		return res_panel;
	}
	
	
	//Создать тегированный текст
	public String getAnalyzedText( ArrayList< MyJapanWord > mjw_list )
	{
		String s_mtse_text = "<html><body style=\"font-size: 25pt\">";
		
		for( MyJapanWord mjw_pos : mjw_list ) 
		{
			if( mjw_pos.getType().indexOf( "adnominal" ) != -1 ) { s_mtse_text += "<font color=\"#BFD000\">" + mjw_pos.getWord() + "</font>"; }
			else if( mjw_pos.getType().indexOf( "noun" ) != -1 ) { s_mtse_text += "<font color=\"#930002\">" + mjw_pos.getWord() + "</font>"; }
			else if( mjw_pos.getType().indexOf( "adverb" ) != -1 ) { s_mtse_text += "<font color=\"#983FFF\">" + mjw_pos.getWord() + "</font>"; }
			else if( mjw_pos.getType().indexOf( "alverb" ) != -1 ) { s_mtse_text += "<font color=\"#6600E3\">" + mjw_pos.getWord() + "</font>"; }
			else if( mjw_pos.getType().indexOf( "verb" ) != -1 ) { s_mtse_text += "<font color=\"#2C0093\">" + mjw_pos.getWord() + "</font>"; }
			else if( mjw_pos.getType().indexOf( "adjective" ) != -1 ) { s_mtse_text += "<font color=\"#007F15\">" + mjw_pos.getWord() + "</font>"; }
			else if( mjw_pos.getType().indexOf( "particle" ) != -1 ) { s_mtse_text += "<font color=\"#D09200\">" + mjw_pos.getWord() + "</font>"; }
			else if( mjw_pos.getType().indexOf( "symbol" ) != -1 ) { s_mtse_text += "<font color=\"#000000\">" + mjw_pos.getWord() + "</font>"; }
			else { s_mtse_text += "<font color=\"#000000\">" + mjw_pos.getWord() + "</font>"; }
		}
		
		return s_mtse_text + "</body></html>";
	}
	
	
	//Нажатие на кнопку-слово (копировать в буфер)
	public class ALWordButtPress implements ActionListener 
	{
		String s_word = null;
		public ALWordButtPress( String s_word ) { this.s_word = s_word; }
		
		public void actionPerformed( ActionEvent ae )
		{
			if( s_word != null ) 
			{
				StringSelection selection = new StringSelection( s_word );
				Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
				clipboard.setContents( selection, selection );
			}
		}
	}
}
