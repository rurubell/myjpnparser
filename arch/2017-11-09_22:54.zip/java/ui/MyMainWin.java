package src.ui;


import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import javax.swing.border.*;
import java.awt.event.*;
import javax.swing.event.*;

import src.ui.panel.MyAnalyzedSentensePanel;
import src.ui.panel.*;
import src.ui.button.*;
import src.ui.win.*;
import src.ui.menu.*;

import src.data.MyJapanWord;
import src.jap.MyJapTextAnalyzer;
import src.jap.simkanji.MySimKanji;


public class MyMainWin extends JFrame
{
	public MyMainWin p_self_link = this;
	public JPanel main_panel = new JPanel();
	
	//Ссылка на панель с тегированным текстом
	MyAnalyzedSentensePanel masp = null;
	//Ссылка на панель со словарем
	MyJishoPanel mjp = null;
	//Ссылка на панель с переводом
	MyTranslateShellPanel mtsp = null;
	//Окно, со списком похожих канзи
	MySimKanjiWin mskw = null;
	
	
	public MyMainWin( String s_sentense )
	{
		this.setDefaultCloseOperation( WindowConstants.DO_NOTHING_ON_CLOSE );
		this.addWindowListener( new WAClose() );
		this.setLocation( 100, 100 );
		this.setTitle( "jwrdmem - " + s_sentense.replace( "\n", "" ) );
		
		this.main_panel.setLayout( new BoxLayout( main_panel, BoxLayout.PAGE_AXIS ) );
		main_panel.add( this.makeRecognizedPanel( s_sentense ) );
		
		this.add( main_panel );
		this.pack();
	}
	
	
	//Создать панель с полем распознанного текста
	private JPanel makeRecognizedPanel( String s_sentense )
	{
		//Главная панель
		JPanel res_panel = new JPanel();
		res_panel.setLayout( new BoxLayout( res_panel, BoxLayout.PAGE_AXIS ) );
		Border b_titled = BorderFactory.createTitledBorder( "Recognized sentense" );
		res_panel.setBorder( b_titled );
		
		//Текстовое поле с распознанным текстом
		JTextPane recogn_text_pane = new JTextPane();
		Border b_comp_bord = new CompoundBorder
		(
			BorderFactory.createLineBorder( Color.decode( "#444444" ) ), 
			BorderFactory.createMatteBorder( 5, 5, 5, 5, Color.decode( "#FFFFFF" ) )
		);
		recogn_text_pane.setBorder( b_comp_bord );
		recogn_text_pane.setBorder( b_comp_bord );
		recogn_text_pane.addCaretListener( new CLSimKanji( recogn_text_pane ) );
		recogn_text_pane.setContentType( "text/html" );
		recogn_text_pane.setFont( new Font( "Sans", Font.BOLD, 25 ) );
		s_sentense = s_sentense.replace( "\n", "<br/>" );
		recogn_text_pane.setText(  "<html><body style=\"font-size: 25pt\">" + s_sentense + "</body></html>" );
		
		//Меню для текстового поля
		MyRecognizedJTextPaneMenu mjtfm = new MyRecognizedJTextPaneMenu( recogn_text_pane );
		recogn_text_pane.setComponentPopupMenu( mjtfm );
		
		//Кнопки и их панели
		JButton jb_tage_and_translate = new JButton( "Analyze and Translate" );
		MyRecognizedPanelEditButton jb_crop = new MyRecognizedPanelEditButton( "Crop" );
		MyRecognizedPanelEditButton jb_del_latin = new MyRecognizedPanelEditButton( "Del Latin" );
		
		Border b_border = BorderFactory.createLineBorder( Color.decode( "#999999" ) );
		JPanel edit_butt_panel = new JPanel();
		edit_butt_panel.setBorder( b_border );
		JPanel tagetransl_butt_panel = new JPanel();
		tagetransl_butt_panel.setBorder( b_border );
		
		edit_butt_panel.add( jb_crop );
		edit_butt_panel.add( jb_del_latin );
		tagetransl_butt_panel.add( jb_tage_and_translate );
		
		jb_tage_and_translate.addActionListener( new ALTagAndTranslate( recogn_text_pane ) );
		jb_crop.addActionListener( new ALCrop( recogn_text_pane ) );
		jb_del_latin.addActionListener( new ALDelLatin( recogn_text_pane ) );
		
		JPanel button_panel = new JPanel();
		button_panel.add( edit_butt_panel );
		button_panel.add( tagetransl_butt_panel );
		
		res_panel.add( recogn_text_pane );
		res_panel.add( button_panel );
		
		return res_panel;
	}
	
	
	//Событые нажатия на кнопку "Tag and Translate"
	public class ALTagAndTranslate implements ActionListener 
	{
		private JTextPane text_pane = null;
		public ALTagAndTranslate( JTextPane text_pane ) { this.text_pane = text_pane; }
		
		public void actionPerformed( ActionEvent ae )
		{
			String s_text = "";
			try { s_text = this.text_pane.getDocument().getText( 0, text_pane.getDocument().getLength() ); }
			catch( Exception e ) { e.printStackTrace(); }
			
			MyJapTextAnalyzer mjta = new MyJapTextAnalyzer();
			s_text = s_text.replace( "\n", "" );
			s_text = s_text.replace( " ", "" );
			ArrayList< MyJapanWord > mjw_list = mjta.getWordsArrayList( s_text );
			
			try
			{
				main_panel.remove( masp );
				main_panel.remove( mjp.getPanel() );
				main_panel.remove( mtsp.getPanel() );
			} 
			catch( Exception e ) {}
			
			masp = new MyAnalyzedSentensePanel( mjw_list );
			mjp = new MyJishoPanel( mjw_list );
			mtsp = new MyTranslateShellPanel( s_text );
			this.text_pane.setText( masp.getAnalyzedText( mjw_list ) );
			
			try
			{
				mjp.start();
				mtsp.start();
				mjp.join();
				mtsp.join();
			}
			catch( Exception e ) { e.printStackTrace(); }
			
			main_panel.add( masp );
			main_panel.add( mjp.getPanel() );
			main_panel.add( mtsp.getPanel() );
			main_panel.repaint();
			main_panel.revalidate();
			
			p_self_link.pack();
			System.gc();
		}
	}
	
	
	//Событие при выделении текста в поле распознанныхъ кандзи
	public class CLSimKanji implements CaretListener 
	{
		private JTextPane text_pane = null;
		public CLSimKanji( JTextPane text_pane ) { this.text_pane = text_pane; }
		
		public void caretUpdate( CaretEvent ce )
		{
			MySimKanji msk = new MySimKanji();
			String s_similar = msk.getSimilar( this.text_pane.getSelectedText() );
			
			try{ mskw.setVisible( false ); } catch ( Exception e ) {}
			
			if( s_similar.length() > 0 )
			{
				mskw = new MySimKanjiWin( s_similar, this.text_pane );
				mskw.setVisible( true );
			}
		}
	}
	
	
	//Событие при закрытии окна
	public class WAClose extends WindowAdapter
	{
		public void windowClosing( WindowEvent we )
		{
			try { mskw.setVisible( false ); } catch ( Exception e ) {}
			p_self_link.setVisible( false );
		}
	}
	
	
	//Хендлер кнопки - Del Latin
	public class ALDelLatin implements ActionListener 
	{
		private JTextPane text_pane = null;
		public ALDelLatin( JTextPane text_pane ) { this.text_pane = text_pane; }
		
		public void actionPerformed( ActionEvent ae )
		{
			String s_text = "";
			try { s_text = this.text_pane.getDocument().getText( 0, text_pane.getDocument().getLength() ); }
			catch( Exception e ) { e.printStackTrace(); }
			String s_latin = "!?.,\'\"\\|+=-)({}[]<>!@#$%^&*~`′";
			
			for( int i = 0; i < s_latin.length(); i++ )
			{
				s_text = s_text.replace( s_latin.substring( i, i + 1 ), "" );
			}
			
			this.text_pane.setText( "<html><body style=\"font-size: 25pt\">" + s_text + "</body></html>" );
		}
	}
	
	
	//Crop
	public class ALCrop implements ActionListener 
	{
		private JTextPane text_pane = null;
		public ALCrop( JTextPane text_pane ) { this.text_pane = text_pane; }
		
		public void actionPerformed( ActionEvent ae )
		{
			String s_text = this.text_pane.getSelectedText();
			if( s_text != null ) { this.text_pane.setText( "<html><body style=\"font-size: 25pt\">" + s_text + "</body></html>" ); }
		}
	}
}
