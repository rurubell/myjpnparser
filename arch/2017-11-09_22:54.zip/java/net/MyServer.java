package src.net;


import java.net.*;
import java.io.*;

import src.jap.MyJapTextAnalyzer;
import src.data.MyJapanWord;
import src.ui.MyMainWin;
import src.util.MyExec;
import src.params.MyParams;
import src.util.log.MyLogToStdout;


public class MyServer 
{
	public static void startServer()
	{
		int port = 7777;
		MyLogToStdout mlts = new MyLogToStdout();
		
		try 
		{
			while( true )
			{
				ServerSocket ss = new ServerSocket( port );
				mlts.writeMess( "Waiting for a new client..." );
				
				Socket socket = ss.accept();
				mlts.writeMess( "Got a client..." );
				
				InputStreamReader isr = new InputStreamReader( socket.getInputStream(), "UTF-8" );
				BufferedReader in = new BufferedReader( isr );
				
				String s_mess = "";
				String line = null;
				while( ( line = in.readLine() ) != null ) { s_mess += line + "\n"; }
				//Удаляем последний \n, зачем нам пустая строка?
				if( s_mess.length() > 1 ) { s_mess = s_mess.substring( 0, s_mess.length() - 1 ); }
				
				mlts.writeMess( "Client say: " + s_mess );
				MyMainWin mmw = new MyMainWin( s_mess );
				mmw.setVisible( true );
				
				ss.close();
				mlts.jump();
			}
		}
		catch( Exception e ) { e.printStackTrace(); }
	}
}
