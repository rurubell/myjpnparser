package src.jap.elib;


import java.util.ArrayList;
import java.net.URLEncoder;

import src.net.MyGetSender;


//Класс для работы с интернет словарем http://e-lib.ua
public class MyELIB
{
	private String s_elib_url_1 = "http://e-lib.ua/dic/results?w=";
	private String s_elib_url_2 = "&m=0";
	
	private String s_word = "";
	
	
	public MyELIB( String s_word )
	{
		try { this.s_word = URLEncoder.encode( s_word, "UTF-8" ); }
		catch( Exception e ) { e.printStackTrace(); }
	}
	
	
	public String getTranslation()
	{
		String s_res = "";
		
		MyGetSender mgs = new MyGetSender();
		String s_resp = mgs.sendGET( this.s_elib_url_1 + this.s_word + this.s_elib_url_2 );
		
		s_res = this.deleteTrashDivs( s_resp );
		
		return s_res;
	}
	
	
	//Удалить лишние блоки из html блока
	private String deleteTrashDivs( String s_html_response )
	{
		String s_res = "";
		
		try
		{
			int n_start_index = s_html_response.indexOf( "<div class=\"kanjipic\">" );
			int n_end_index = s_html_response.indexOf( "</div>", n_start_index ) + new String( "</div>" ).length();
			String s_div_block = s_html_response.substring( n_start_index, n_end_index );
			s_html_response = s_html_response.replace( s_div_block, "" );
		} catch ( Exception e ) {}
		
		try
		{
			int n_start_index = s_html_response.indexOf( "<div class=\"akusentoblock\">" );
			int n_end_index = s_html_response.indexOf( "</div>", n_start_index )  + new String( "</div>" ).length();
			String s_div_block = s_html_response.substring( n_start_index, n_end_index );
			s_html_response = s_html_response.replace( s_div_block, "" );
		} catch ( Exception e ) {}
		
		try
		{
			s_html_response = s_html_response.replace( "<!--|-->", "" );
		} catch ( Exception e ) {}
		
		s_res = s_html_response + "<br/><br/>";
		return s_res;
	}
}
