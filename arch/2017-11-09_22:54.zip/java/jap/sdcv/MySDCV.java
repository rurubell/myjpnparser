package src.jap.sdcv;


import java.util.ArrayList;

import src.util.MyExec;


//Класс для работы с выхлопом словаря SDCV
public class MySDCV
{
	//Максимальное количество результатов (слишком много не надо)
	private int N_MAX_RESULTS = 5;
	
	
	public String translate( String s_word )
	{
		MyExec me = new MyExec();
		ArrayList< String > sdcv_out = me.executeCommandAndGetList( "sdcv -n " + s_word );
		if( this.isContainsString( sdcv_out, "sorry :(" ) ) { return null; }
		//Если слишком много результатов, нафиг не надо...
		if( !this.isContainsString( sdcv_out, "Found 1 items, similar to" ) ) { return null; }
		String s_res = "";
		
		//Извлекаем первый результат из списка
		int n_start = this.getPositionOfNullLengthString( sdcv_out, 0 ) + 1;
		int n_end = this.getPositionOfNullLengthString( sdcv_out, n_start );
		if( ( n_end - n_start ) > N_MAX_RESULTS ) { n_end = n_start + N_MAX_RESULTS; }
		
		for( int i = n_start; i < n_end; i++ )
		{
			if( (i + 1) == n_end ) { s_res += sdcv_out.get(i); break; }
			s_res += sdcv_out.get(i) + ", ";
		}
		
		return s_res;
	}
	
	
	//Поиск строки в ArrayLis'е
	private boolean isContainsString( ArrayList< String > list, String s_str )
	{
		for( String s_pos : list )
		{
			if( s_pos.indexOf( s_str ) != -1 ) { return true; }
		}
		
		return false;
	}
	
	
	//Поиск позиции строки нулевой длинны в листе, начиная с оффсета
	private int getPositionOfNullLengthString( ArrayList< String > list, int n_offset )
	{
		for( int i = n_offset; i < list.size(); i++ )
		{
			if( list.get(i).length() <= 0 ) { return i; }
		}
		
		return -1;
	}
}
