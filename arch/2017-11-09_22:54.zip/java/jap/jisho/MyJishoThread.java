package src.jap.jisho;


import src.net.MyGetSender;
import src.data.MyJishoAnswer;
import java.net.URLEncoder;


public class MyJishoThread extends Thread
{
	private String s_jisho_api_link = "http://jisho.org/api/v1/search/words?keyword=";
	
	
	private String s_word = null;
	private MyJishoAnswer mja = null;
	
	
	MyJishoThread( String s_word ) 
	{
		try { this.s_word = URLEncoder.encode( s_word, "UTF-8" ); }
		catch( Exception e ) { e.printStackTrace(); }
	}
	
	//Получить ответ
	public MyJishoAnswer getJishoAnswer() { return this.mja; }
	
	
	@Override
	public void run()
	{
		MyGetSender mgs = new MyGetSender();
		String s_resp = mgs.sendGET( this.s_jisho_api_link + this.s_word );
		this.mja = new MyJishoAnswer( this.s_word, s_resp );
	}
}
