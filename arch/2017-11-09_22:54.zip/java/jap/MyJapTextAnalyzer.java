package src.jap;


import java.util.ArrayList;

import org.atilika.kuromoji.Token;
import org.atilika.kuromoji.Tokenizer;
import java.lang.reflect.Method;

import src.data.MyJapanWord;
import src.util.log.MyLogToStdout;


public class MyJapTextAnalyzer
{
	private static Tokenizer tokenizer = null;
	private static boolean b_flag = true;
	
	public MyJapTextAnalyzer()
	{
		if( this.b_flag )
		{
			MyLogToStdout mlts = new MyLogToStdout();
			mlts.writeMess( "Kuromoji init..." );
			this.tokenizer = Tokenizer.builder().build();
			this.b_flag = false;
		}
	}
	
	
	//Получить ArrayList слов и их типов
	public ArrayList< MyJapanWord > getWordsArrayList( String s_text )
	{
		ArrayList< MyJapanWord > res_list = new ArrayList< MyJapanWord >();
		
		for( Token token : tokenizer.tokenize( s_text ) )
		{
			String s_type = this.getWordType( token );
			MyJapanWord mjw = new MyJapanWord
			( 
				token.getSurfaceForm(), 
				s_type,
				token.getReading(),
				token.getBaseForm()
			);
			
			res_list.add( mjw );
		}
		
		return res_list;
	}
	
	
	//Определить тип слова
	private String getWordType( Token token )
	{
		if( token.getPartOfSpeech().indexOf( "連体詞," ) != -1 ) { return "adnominal"; }
		if( token.getPartOfSpeech().indexOf( "名詞," ) != -1 ) { return "noun"; }
		if( token.getPartOfSpeech().indexOf( "動詞," ) != -1 ) { return "verb"; }
		if( token.getPartOfSpeech().indexOf( "助動詞," ) != -1 ) { return "alverb"; }
		if( token.getPartOfSpeech().indexOf( "副詞," ) != -1 ) { return "adverb"; }
		if( token.getPartOfSpeech().indexOf( "形容詞," ) != -1 ) { return "adjective"; }
		if( token.getPartOfSpeech().indexOf( "助詞," ) != -1 ) { return "particle"; }
		if( token.getPartOfSpeech().indexOf( "記号," ) != -1 ) { return "symbol"; }
		
		return "none";
	}
}
