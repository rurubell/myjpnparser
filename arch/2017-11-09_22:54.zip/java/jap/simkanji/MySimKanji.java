package src.jap.simkanji;


import java.util.ArrayList;
import java.util.HashMap;

import src.data.MySimKanjiEntry;
import src.data.MyJapanWord;
import src.file.MyTextFileReader;
import src.params.MyParams;
import src.util.log.MyLogToStdout;


public class MySimKanji
{
	//Карта которая хранит список канзи (ключ) - строка похожих канзи
	private static HashMap< String, String > res_map = new HashMap< String, String >();
	private static boolean b_flag = true;
	
	
	public MySimKanji()
	{
		if( this.b_flag )
		{
			this.b_flag = false;
			this.res_map = this.readToHashMap();
		}
	}
	
	
	//Читаем все списки похожих канзи в карту
	private HashMap< String, String > readToHashMap()
	{
		MyLogToStdout mlts = new MyLogToStdout();
		mlts.writeMess( "Read simkanji file: \"" + MyParams.getStringValue( "simkanji_path" ) + "\"..." );
		HashMap< String, String > res_map = new HashMap< String, String >();
		ArrayList< MySimKanjiEntry > mske_list = MySimKanjiEntry.getFileAsListOfMJLPTW( MyParams.getStringValue( "simkanji_path" ) );
		
		int i = 0;
		for( MySimKanjiEntry mske_pos : mske_list )
		{
			res_map.put
			(
				mske_pos.getKanji(),
				mske_pos.getSimilar()
			); 
		}
		
		return res_map;
	}
	
	
	//Получить похожие кандзи
	public String getSimilar( String s_kanji )
	{
		String s_res = this.res_map.get( s_kanji );
		
		if( s_res == null ) { return ""; }
		return s_res;
	}
}
