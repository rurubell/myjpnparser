package src.data;


import java.util.ArrayList;

import src.util.log.MyLogToStdout;
import src.file.MyTextFileReader;


public class MySimKanjiEntry
{
	private String s_kanji = "";
	private String s_similar = "";
	
	private void setKanji( String s_kanji ) { this.s_kanji = s_kanji; }
	private void setSimilar( String s_similar ) { this.s_similar = s_similar; }
	
	public String getKanji() { return this.s_kanji; }
	public String getSimilar() { return this.s_similar; }
	
	
	public MySimKanjiEntry() {}
	
	
	//Получить файл как лист MySimKanjiEntry
	public static ArrayList< MySimKanjiEntry > getFileAsListOfMJLPTW( String s_path )
	{
		ArrayList< MySimKanjiEntry > res_list = new ArrayList< MySimKanjiEntry >();
		MyTextFileReader mtfr = new MyTextFileReader();
		
		for( String s_pos : mtfr.readFileAsStringAL( s_path ) )
		{
			if( MySimKanjiEntry.isCorrectString( s_pos ) ) 
			{
				MySimKanjiEntry mske_pos = new MySimKanjiEntry();
				mske_pos = mske_pos.parseFileStringtoMJLPTW( s_pos );
				res_list.add( mske_pos ); 
			}
		}
		
		return res_list;
	}
	
	
	//Распарсить файловую строку в объект типа MyJLPTWord
	public MySimKanjiEntry parseFileStringtoMJLPTW( String s_file_string )
	{
		MySimKanjiEntry mske = new MySimKanjiEntry();
		
		mske.setKanji( this.parseKanji( s_file_string ) );
		mske.setSimilar( this.parseSimKanji( s_file_string ) );
		
		return mske;
	}
	
	
	//Проверка строки на корректность
	public static boolean isCorrectString( String s_string )
	{
		if
		(
			( s_string.indexOf( "<knj>" ) != -1 ) && 
			( s_string.indexOf( "</knj>" ) != -1 ) && 
			( s_string.indexOf( "<sim>" ) != -1 ) && 
			( s_string.indexOf( "</sim>" ) != -1 )
		)
		{ return true; }
		return false;
	}
	
	
	//Распарсить кандзи
	private String parseKanji( String s_string )
	{
		MyLogToStdout mlts = new MyLogToStdout();
		String s_res = "";
		String s_start_tag = "<knj>";
		String s_end_tag = "</knj>";
		
		try
		{
			int n_start = s_string.indexOf( s_start_tag ) + s_start_tag.length();
			int n_end = s_string.indexOf( s_end_tag );
			s_res = s_string.substring( n_start, n_end );
		}
		catch( Exception e ) { mlts.writeMess( "Не удалось прочесть кандзи из строки - \"" + s_string + "\"" ); }
		
		return s_res;
	}
	
	
	//Распарсить похожие канзи
	private String parseSimKanji( String s_string )
	{
		MyLogToStdout mlts = new MyLogToStdout();
		String s_res = "";
		String s_start_tag = "<sim>";
		String s_end_tag = "</sim>";
		
		try
		{
			int n_start = s_string.indexOf( s_start_tag ) + s_start_tag.length();
			int n_end = s_string.indexOf( s_end_tag );
			s_res = s_string.substring( n_start, n_end );
		}
		catch( Exception e ) { mlts.writeMess( "Не удалось прочесть похожие канзи из строки - \"" + s_string + "\"" ); }
		
		return s_res;
	}
	
	
	//Печать в консоль
	public void show()
	{
		System.out.println( "Kanji: " + this.getKanji() );
		System.out.println( "Similar: " + this.getSimilar() );
	}
}
