#!/usr/bin/perl


use strict;
use warnings;
use Cwd 'abs_path';


#Путь до скрипта
my $S_SELF_PATH = abs_path( $0 );
#Путь до директории скрипта
my $S_SELF_DIR_PATH = `dirname $S_SELF_PATH`;
chomp( $S_SELF_DIR_PATH );
#Переходим в директорию скрипта
chdir( $S_SELF_DIR_PATH ) or die "Не могу зайти в директорию " . $S_SELF_DIR_PATH . " !\n";

my $s_date = `date +%F`;
chomp( $s_date );

my $s_logfile_path = "./log/" . $s_date . ".log";
system ( "mkdir -p ./log" );
system( "java -Xmx512m -XX:+UseG1GC -XX:MinHeapFreeRatio=1 -XX:MaxHeapFreeRatio=5 -jar ./myjpnparser.jar >> " . $s_logfile_path );
